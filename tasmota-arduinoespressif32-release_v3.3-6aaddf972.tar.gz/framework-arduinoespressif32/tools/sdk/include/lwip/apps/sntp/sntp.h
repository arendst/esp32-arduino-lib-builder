#pragma once
#warning "This header file is deprecated, please include esp_sntp.h instead."
#include "esp_sntp.h"
